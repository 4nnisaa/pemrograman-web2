<?= $this->extend('template')?>

<?= $this->section('main')?>

<div class="container">
    <h2 class="mb-5">Anda berhasil Membuat Order</h2>
    <div class="mb-3">
        <div class="alert alert-success">
            <strong>Sukses</strong>Silahkan melakukan dan mengirim bukti bayar ke Admin via Whatsapp. 
            <a href="https://wa.me/085281990429" class="btn btn-success">Hubungi Admin</a>
        </div>
    </div>
</div>

<?= $this->endSection()?>